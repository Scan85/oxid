<?php
/**
 * Shop version
 */

$this->version = '4.10.2';

