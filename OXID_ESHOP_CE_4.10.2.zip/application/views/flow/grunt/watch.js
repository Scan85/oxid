module.exports = {

    development: {
        files: [ "build/**/*.js", "build/**/*.less" ],
        tasks: [ "development" ]
    }

};